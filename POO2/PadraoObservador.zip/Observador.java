
/**
 * Escreva a descrição da interface Observador aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface Observador
{
    /**
     * Exemplo de um cabeçalho de método - substitua este comentário pelo seu
     * 
     * @param  y    exemplo de um parâmetro de método
     * @return        o resultado produzido pelo sampleMethod 
     */
    public void atualiza(int precoIBM, int precoIntel, int precoApple, int precoGoogle);
}
