
/**
 * Escreva uma descrição da classe Bolsa aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
import java.util.ArrayList;
public class Bolsa implements Sujeito
{
    private ArrayList<Observador> observadores = new ArrayList<Observador>();
    private int _precoIBM_, _precoIntel_, _precoApple_, _precoGoogle_;
    
    
    public Bolsa()
    {
    }
    
    public void registra(Observador o){observadores.add(o);}
    public void apagar(Observador o){}
    public void notificaObservador(){
        for(Observador atual : observadores){
            atual.atualiza(_precoIBM_, _precoIntel_, _precoApple_, _precoGoogle_);
        }
    }
    
    public void setPrecoIBM(int novoPreco){this._precoIBM_=novoPreco;notificaObservador();}
    public void setPrecoApple(int novoPreco){this._precoApple_ =novoPreco;notificaObservador();}
    public void setPrecoGoole(int novoPreco){this._precoGoogle_ =novoPreco;notificaObservador();}
    public void setPrecoIntel(int novoPreco){this._precoIntel_ =novoPreco;notificaObservador();}

}
