
/**
 * Escreva uma descrição da classe Investidor aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Investidor implements Observador
{
    private int precoIBM, precoIntel, precoGoogle, precoApple,IDObs;
    private static int contador;
    private Sujeito bolsa;
    
    public Investidor(Sujeito _bolsa)
    {
        this.bolsa=_bolsa;
        this.IDObs=++contador;
        System.out.println("Novo observador registrado: "+this.IDObs);
        bolsa.registra(this);
    }
    
    private void exibirPrecos(){
        System.out.println("Observador: "+this.IDObs+" IBM: "+precoIBM +" Intel: "+precoIntel
        +" Google: "+precoGoogle +" Apple: "+precoApple);
    }
    
    public void atualiza(int _paramIBM, int _paramApple, int _paramGoogle, int _paramIntel){
        this.precoIBM=_paramIBM;this.precoApple=_paramApple;this.precoGoogle=_paramGoogle;
        this.precoIntel=_paramIntel;
        exibirPrecos();
    }

}
