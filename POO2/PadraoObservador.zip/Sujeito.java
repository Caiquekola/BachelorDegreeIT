
/**
 * Escreva a descrição da interface Sujeito aqui.
 * 
 * @author (seu nome aqui) 
 * @version (um número da versão ou data aqui)
 */

public interface Sujeito
{
    /**
     * Exemplo de um cabeçalho de método - substitua este comentário pelo seu
     * 
     * @param  y    exemplo de um parâmetro de método
     * @return        o resultado produzido pelo sampleMethod 
     */
    public void registra(Observador o);
    public void apagar(Observador o);
    public void notificaObservador();
    
}
