
/**
 * Escreva uma descrição da classe Principal aqui.
 * 
 * @author (seu nome) 
 * @version (um número da versão ou uma data)
 */
public class Principal
{
    public static void main(String[] aaaaaaaaaaaaaaa){
        Bolsa b1 = new Bolsa();

        Investidor i1 = new Investidor(b1);
        Investidor i2 = new Investidor(b1);
        Investidor i3 = new Investidor(b1);
        Investidor i4 = new Investidor(b1);

        b1.setPrecoApple(100);b1.setPrecoGoole(700);
        b1.setPrecoIBM(300);b1.setPrecoIntel(1132);

    }

}
